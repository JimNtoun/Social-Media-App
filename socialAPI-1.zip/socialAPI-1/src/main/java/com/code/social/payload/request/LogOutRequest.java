package com.code.social.payload.request;

public class LogOutRequest {
	  private Long userId;

	  public Long getUserId() {
	    return this.userId;
	  }
	}
package com.code.social;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SocialApi1Application {

	public static void main(String[] args) {
		SpringApplication.run(SocialApi1Application.class, args);
	}

}

package com.code.social.security;

public interface CurrentUser {

}
